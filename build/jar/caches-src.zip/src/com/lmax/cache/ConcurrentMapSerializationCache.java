package com.lmax.cache;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

// perf =  mops
public class ConcurrentMapSerializationCache implements SerializationCache {

    private final ConcurrentMap<Integer, byte[]> map;

    public ConcurrentMapSerializationCache(int size) {
        map = new ConcurrentHashMap<Integer, byte[]>(size);
    }

    @Override
    public void put(int id, byte[] bytes) {
        map.put(id, bytes);
    }

    @Override
    public byte[] get(int id) {
        return map.get(id);
    }

}