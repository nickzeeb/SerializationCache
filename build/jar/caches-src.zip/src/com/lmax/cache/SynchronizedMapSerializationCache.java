package com.lmax.cache;

import java.util.HashMap;

// perf =  mops
public class SynchronizedMapSerializationCache implements SerializationCache {

    private final HashMap<Integer, byte[]> map;

    public SynchronizedMapSerializationCache(int size) {
        map = new HashMap<Integer, byte[]>(size);
    }

    @Override
    public synchronized void put(int id, byte[] bytes) {
        map.put(id, bytes);
    }

    @Override
    public synchronized byte[] get(int id) {
        return map.get(id);
    }

}