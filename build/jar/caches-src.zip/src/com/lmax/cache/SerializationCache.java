package com.lmax.cache;

public interface SerializationCache {

    void put(int id, byte[] bytes);

    byte[] get(int id);

}