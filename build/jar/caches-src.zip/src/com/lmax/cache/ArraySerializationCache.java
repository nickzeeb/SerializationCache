package com.lmax.cache;

import java.util.Arrays;
import java.util.concurrent.atomic.AtomicReferenceArray;

// perf =  mops
public class ArraySerializationCache implements SerializationCache {

    public static final int EMPTY = -1;
    private final int size;
    private final int[] ids;
    private final AtomicReferenceArray<byte[]> values;

    public ArraySerializationCache(int size) {
        this.size = size;
        this.ids = new int[size];
        this.values = new AtomicReferenceArray<byte[]>(size);

        Arrays.fill(ids, EMPTY);
    }

    @Override
    public void put(int id, byte[] bytes) {
        for (int i = 0; i < size; i++) {

            if (ids[i] == EMPTY) {
                ids[i] = id;
                values.set(i, bytes);
                return;
            }

            else if (ids[i] == id) {
                values.set(i, bytes);
                return;
            }
        }
    }

    @Override
    public byte[] get(int id) {
        for (int i = 0; i < size; i++) {
            if (ids[i] == id) {
                return values.get(i);
            }
        }

        return null;
    }

}