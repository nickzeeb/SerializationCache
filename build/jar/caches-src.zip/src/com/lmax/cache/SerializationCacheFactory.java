package com.lmax.cache;

public class SerializationCacheFactory {

    public static SerializationCache build(int size) {
        return new SynchronizedMapSerializationCache(size);
//        return new ConcurrentMapSerializationCache(size);
//        return new ArraySerializationCache(size);
//        return new LazyArraySerializationCache(size);
    }

}