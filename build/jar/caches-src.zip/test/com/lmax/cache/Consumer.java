package com.lmax.cache;

import static com.lmax.cache.Utils.computeId;

class Consumer extends Thread {
    private final int cacheSize;
    private final SerializationCache cache;
    private volatile boolean stop;

    byte[][] values;
    long numberOfUpdates;

    Consumer(SerializationCache cache, int cacheSize) {
        super("Consumer");
        this.cache = cache;
        this.cacheSize = cacheSize;
        this.values = new byte[cacheSize][];
    }

    @Override
    public void run() {
        while (!stop) {
            int id = computeId(numberOfUpdates++, cacheSize);
            byte[] bytes = cache.get(id);
            values[id] = bytes;
        }
    }

    public void endRun() {
        stop = true;
    }

}