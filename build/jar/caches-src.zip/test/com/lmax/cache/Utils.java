package com.lmax.cache;

import java.util.Arrays;

public class Utils {

    private Utils() {}

    public static int computeId(long counter, int max) {
        for (int i = 0; i < max; i++) {

            if ((counter & 1) == 0) {
                return i;
            }

            counter >>= 1;
        }

        return max - 1;
    }

    public static void main(String[] args) {
        int max = 8;
        int[] counts = new int[max];

        for (int i = 0; i < 7; i++) {
            int id = computeId(i, max);
            System.out.println(id);

            counts[id]++;
        }

        System.out.println(Arrays.toString(counts));
    }

}
