package com.lmax.cache;

import static com.lmax.cache.Utils.computeId;

class Producer extends Thread {

    private final SerializationCache cache;
    private final byte[][] bytes;

    private volatile boolean stop;

    Producer(SerializationCache cache, byte[][] bytes) {
        super("Producer");
        this.cache = cache;
        this.bytes = bytes;
    }

    @Override
    public void run() {
        long counter = 0;

        while(!stop) {
            int id = computeId(counter++, bytes.length);
            cache.put(id, bytes[id]);
        }
    }

    public void endRun() {
        stop = true;
    }

}